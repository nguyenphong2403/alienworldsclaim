# Alien-Worlds-Auto-Mining-Bot-Solving-Captha
 This bot automatically mines TLM and solves the captcha through the Anti-Captha service

The first working bot for the game Alien Worlds. You will never be banned. The bot always mines with a different delay, so the game thinks that you are a real person.

English/Russian

English:
Download: Code => download zip

And so let's proceed with the installation.

Bot setup:

1. Download Python on 3.8 Windows x86–64 executable installer
2. Install it, do not forget to select the ADD TO PATH checkbox
3. Transfer the folder with the bot to the desktop for convenience, rename it to AWbot (the path to main.py should be something like this / desktop / AWbot (this is the name of the folder with the bot) /main.py
4. Go to the console (CMD) and write cd desktop / awbot Or cd desktop, cd awbot
5. pip install -r requirements.txt
6. Perhaps he will swear at the version pip, then write a command that will appear in the console
7. pip install selenium-requests
8. Install Mozilla Firefox If you already have it, check that the version is 90+
9. Install Node JS 14.17 LTS (as of 05/13/2021)
10. Go to config.py and in the CAPTCHA_KEY = 'YOUR KEY' field insert your captcha key https://anti-captcha.com/ (Works only on it) Do not touch the rest in the config, otherwise you will break everything.
11. The bot is ready, it remains to set up your accounts.

Preparing accounts.

1. Making a NEW CHROME profile.
2. Installing the EditThisCookie extension
3. Go to https://all-access.wax.io/
4. Log in to your account and be careful
5. After login, there will be such a window

https://i.ibb.co/LJcsvzM/1-R2g0wpu-K45-VCgzl-ICg-ECk-A.jpg

6. You will have 3 seconds to left-click on the browser and click on EditThisCookie
7. If you did everything correctly, you will see such a window. The site must be https://all-access.wax.io/

https://i.ibb.co/9w6sKJY/1-Oq-FEm8-Qm6u1wi-FNLXKLFKw.jpg

8. Do not change anything and click on the button that is marked (export)
9. Open the notebook, paste everything from the clipboard there, do not touch anything.
10. Save it as 1.json (1.json - for the first account, 2 .json - as for the second, etc. FILE TYPE - ALL FILES, not .txt
11. For the rest of the accounts, do steps 3-10

IMPORTANT!!!! After each save the account, CLEAR history in the browser !!!!

8. Do not change anything and click on the button that is marked (import)
9. Open the notebook, paste everything from the clipboard there, do not touch anything.
10. Save it as 1.json (1.json - for the first account, 2 .json - as for the second, etc. FILE TYPE - ALL FILES, not .txt
11. For the rest of the accounts, do steps 3-10

IMPORTANT!!!! After each save the account, CLEAR history in the browser !!!!

INCLUDE BOT

We drop all * .json files into the cookies folder (if not, create them) in the bot. The numbering MUST start with 1.json and continue with 2,3,4,5 ...
Go to the console (CMD) write cd desktop / awbot
Writing python main.py
Let's start the bot
PS if I forgot to indicate something in the guide, the console will write you what else you need to install.
First, it will close all firefox.exe processes, check all the cookies that you have made, if everything goes ok to mine. Sometimes the bot dulls, you just need to restart. If you have a large pool of accounts, then I advise you to run up to 10 accounts first and look at the CPU and RAM load of your Dedicated Server.
I hope you will have time to earn at least as much as I do))
All good and cool TLM farming

Russian:

Скачать: Code=> download zip

И так приступим к установке.

Настройка бота:

1. Качаем Python 3.8 Windows x86–64 executable installer
2. Инсталим его, не забываем выбрать галочку ADD TO PATH
3. Переносим папку с ботом на рабочий стол для удобства переименовываем на AWbot (путь до main.py должен быть примерно таким /desktop/AWbot(это название папки с ботом)/main.py
4. Идем в консоль (CMD) пишем cd desktop/awbot. Или cd desktop , cd awbot
5. pip install -r requirements.txt
6. Возможно он ругнется на версию pip, тогда напишите команду, которая будет в консоле.
7. pip install selenium-requests
8. Устанавливаем Mozilla Firefox. Если уже есть, проверьте чтобы версия была 90+
9. Устанавливаем Node JS 14.17 LTS (на 13.05.2021)
10. Идем в config.py и в поле CAPTCHA_KEY = ‘ВАШ КЛЮЧ’ вставляем свой ключ от капчи https://anti-captcha.com/ (Работает только на ней) Остальное в конфиге не трогайте, а то поламаете все.
11. Бот готов, осталось настроить Ваши аккаунты.

Подготовка аккаунтов.

1. Делаем НОВЫЙ профиль в CHROME.
2. Устанавливаем расширение EditThisCookie
3. Заходим на https://all-access.wax.io/
4. Логинимся в аккаунт и будьте внимательны
5. После логина будет такое вот окно

https://i.ibb.co/LJcsvzM/1-R2g0wpu-K45-VCgzl-ICg-ECk-A.jpg

6. У Вас будет 3 секунды чтобы нажать левой клавишой мышки по браузеру и нажать на EditThisCookie
7. Если все сделали правильно у вас откроется такое окно. Сайт должен быть https://all-access.wax.io/

https://i.ibb.co/9w6sKJY/1-Oq-FEm8-Qm6u1wi-FNLXKLFKw.jpg

8. Ничего не меняйте и нажмите на кнопку что отмечена (export)
9. Открываем блокнот, вставляем туда все из буффера обмена, ничего не трогаем.
10. Сохраняем это как 1.json (1.json — для первого акка, 2 .json— как для второго и т.д. ТИП ФАЙЛА — ВСЕ ФАЙЛЫ, не .txt
11. Для остальных акков проделываем пункты 3–10

ВАЖНО!!!! После каждого сохранения акк, ЧИСТИТЬ историю в браузере!!!!

ВКЛЮЧАЕМ БОТА

Закидываем все *.json файлы в папку cookies (если нет, создаем) в боте. Нумерация ДОЛЖНА начинаться с 1.json и продолжаться 2,3,4,5…
Идем в консоль (CMD) пишем cd desktop/awbot
Пишем python main.py
Пошел запуск бота
P.S. если я что-то забыл указать в гайде, то консоль напишет вам что еще надо доинсталить.
Сначала он закроет все процессы firefox.exe, проверит все куки что вы наделали, если все ок пойдет майнить. Бывает бот затупливает, надо просто перезапустить. Если у вас большой пул акков, то советую запустить сперва ДО 10 акков и посмотреть на нагрузку CPU и RAM вашего дедика.
Надеюсь вы успеете заработать хотя бы столько сколько и я))
Всем добра и крутого фарма ТЛМ